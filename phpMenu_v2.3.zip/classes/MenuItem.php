<?php
	/*** class MenuItem*/
	class MenuItem {

		/** Aggregations: */
		var $title; //item Title

		/*** Attributes: ***/
		var $path; //relative path to Item
		var $base_url; //site URL
		var $css_class; //CSS class name

		/**
		   *
		   * @param string current_url    
		   * @return 
		   * @access public
		   */

		function MenuItem( $my_title, $my_path, $my_class=NULL) {
			$this->title=$my_title;
			$this->path=$my_path;
			$this->css_class=$my_class;
		}

		//function to draw menu Item
		function draw( $current_url ) {
			if(! $this->isVisible($current_url)) {
				return;
			}
			echo '<a href="'.$this->getBaseURL().$this->getPath().'">'.$this->getTitle().'</a>';
		} // end of member function draw

		  /**
		   *
		   * @return string
		   * @access public
		   */

		//function to get item Title
		function getTitle( ) {
			return $this->title;
		} // end of member function getTitle

		  /**
		   *
		   * @param string new_title    
		   * @return 
		   * @access public
		   */

		//function to set item Title
		function setTitle( $new_title ) {
			$this->title=$new_title;
		} // end of member function setTitle

		  /**
		   *
		   * @return string
		   * @access public
		   */

		//function to get relative path to Item
		function getPath( ) {
			return $this->path;
		} // end of member function getPath

		  /**
		   *
		   * @param string new_path    
		   * @return 
		   * @access public
		   */

		//function to set relative path to Item
		function setPath( $new_path ) {
			$this->path=$new_path;
		} // end of member function setPath


		  /**
		   *
		   * @return string
		   * @access public
		   */

		//function to get CSS class name to Item
		function getClass( ) {
			return $this->css_class;
		} // end of member function getClass

		  /**
		   *
		   * @param string new_class    
		   * @return 
		   * @access public
		   */

		//function to set CSS class name to Item
		function setClass( $new_class ) {
			$this->css_class=$new_class;
		} // end of member function setClass


		  /**
		   *
		   * @return string
		   * @access public
		   */

		//function to get site Base URL
		function getBaseURL( ) {
			return $this->base_url;
		} // end of member function getBaseURL

		  /**
		   *
		   * @param string new_base_url    
		   * @return 
		   * @access public
		   */

		//function to set siteBase URL
		function setBaseURL( $new_base_url ) {
			$this->base_url=$new_base_url;
		} // end of member function setBaseURL

		  /**
		   *
		   * @param string current_url
		   * @return bool
		   * @access public
		   */

		//function checks if the Item is Visible
		function isVisible( $current_url ) {
			return TRUE;
		} // end of member function isVisible

		  /**
		   *
		   * @param string current_url    
		   * @return bool
		   * @access public
		   */
		   
		//function checks if Item is Active
		function isActive( $current_url ) {
			if ($this->getBaseURL().$this->getPath() == $current_url) {
				return TRUE;
			} else {
				return FALSE;
			}
		} // end of member function isActive

		  /**
		   *
		   * @param string current_url
		   * @return bool
		   * @access public
		   */

		//function checks if the Item is Empty
		function isEmpty( $current_url ) {
			return FALSE;
		} // end of member function isVisible

	} // end of MenuItem

	//Menu Item that is not Visible in the Menu (is hidden)
	class HiddenItem extends MenuItem {
	
		//function overloads draw method from Menu Item (to draw nothing)
		function draw($current_url) {
		}

		  /**
		   *
		   * @param string current_url    
		   * @return bool
		   * @access public
		   */

		//function returns Menu Item status as invisible
		function isVisible($current_url) {
			return FALSE;
		} // end of member function isVisible

	}

	//Menu Item that is not Visible in the Menu (is hidden)
	class GETQueryHiddenItem extends HiddenItem {

		/*** Attributes: ***/
		var $query_id; //query name
		var $query_value; //query value

	                                                 //   'cat_id'     '0100'
		function GETQueryHiddenItem( $my_title, $my_path, $my_id=NULL, $my_val=NULL, $my_class=NULL ) {
			$this->MenuItem($my_title,$my_path,$my_class);
            $this->query_id=$my_id;
            $this->query_value=$my_val;
		}

		//function checks if Item is Active
		function isActive($current_url) {
			$parsed_nav_url=parse_url($this->getBaseURL().$this->getPath());
			$parsed_current_url=parse_url($current_url);
			if (isset($parsed_nav_url["path"])) {
				$nav_id=$this->query_value;
				$nav_path=$parsed_nav_url['path'];
			} else {
				$nav_id='';
				$nav_path='';
			}
			if ((isset($parsed_current_url["query"])) && (isset($parsed_current_url["path"]))) {
				parse_str($parsed_current_url["query"],$my_array);
				$current_id='';
				$current_path='';
				if ($my_array[$this->query_id] == $this->query_value) {
					$current_id=$my_array[$this->query_id];
					$current_path=$parsed_current_url['path'];
				}
			} else {
				$current_id='';
				$current_path='';
			}
			if (($nav_id == $current_id) && ($nav_path == $current_path)) {
				return TRUE;
			} else {
				return FALSE;
			}
		} // end of member function isActive
		
	}

	//Menu Item is External to the site
	class ExternalItem extends MenuItem {

		//function to draw the External Item (ignores siteBase URL)
		function draw($current_url) {
			if(! $this->isVisible($current_url)) {
				return;
			}
			echo '<a href="'.$this->getPath().'">'.$this->getTitle().'</a>';
		} // end of member function draw

	}

	//Menu Item that is not a link (e.g. for Menu separators)
	//PassiveItem from InactiveItem
	class PassiveItem extends MenuItem {

		function draw($current_url) {
			if(! $this->isVisible($current_url)) {
				return;
			}
			echo $this->getTitle();
		} // end of member function draw

	}
	
	//Menu Item that should not be considered as active
	class InactiveItem extends MenuItem {
		//function returns Item as Inactive at all times
		function isActive( $current_url ) {
			return FALSE;
		} // end of member function isActive


	}

?>