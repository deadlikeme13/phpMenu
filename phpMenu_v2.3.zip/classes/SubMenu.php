<?php

require_once('MenuItem.php');

/*** class SubMenu */
class SubMenu extends MenuItem {

	/** Aggregations: */
	var $elements; //menu items
	
	function SubMenu($my_title, $my_path, $my_class=NULL) {
		//call MenuItem's (superclass) constractor MenuItem
		MenuItem::MenuItem($my_title,$my_path, $my_class);
		$this->elements=array();
	}

	  /**
	   *
	   * @param string current_url   
	   * @return
	   * @access public
	   */

	//function to check if any of the elements in the section are visible
	function anyVisible($current_url) {
		foreach(array_keys($this->elements) as $index){
			if($this->elements[$index]->isVisible($current_url)) {
				return TRUE;
			}
		}
		return FALSE;
	}

	//function to count the number of visible items in the section
	function countVisible($current_url) {
		$count=0;
		foreach(array_keys($this->elements) as $index) {
			if($this->elements[$index]->isVisible($current_url)) {
				$count++;
			}
		}
		return $count;
	}

	//function to draw SubMenu Items
	function draw($current_url) {
		if(! $this->isVisible($current_url)) { 
			return;
		}
		//call MenuItem's (superclass) method draw
		MenuItem::draw($current_url);
		//if there any active elements in SubMenu draw all of them that are visible
		if($this->isActive($current_url)) {
			$any=$this->anyVisible($current_url);
			if($any) {
				echo "<ul>";
			}
			foreach(array_keys($this->elements) as $index) {
				if (! $this->elements[$index]->isEmpty($current_url)) {
					if($this->elements[$index]->isVisible($current_url) and $this->elements[$index]->isActive($current_url)) {
						echo '<li class="active">';
					} elseif ($this->elements[$index]->isVisible($current_url) ) {
						$mc=$this->elements[$index]->getClass();
						if (!empty ($mc)) {
							echo '<li class="'.$mc.'">';
						} else {
							echo '<li>';
						}
					}
					$this->elements[$index]->draw( $current_url );
					if($this->elements[$index]->isVisible($current_url)) {
						echo "</li>";
					}
				}
			}
			if($any) { echo "</ul>";}
		}
	} // end of member function draw



	  /**
	   *
	   * @param MenuItem item    
	   * @return 
	   * @access public
	   */

	
	//function to add Item
	function addItem($item) {
		$item->setBaseURL($this->getBaseURL());
		array_push($this->elements,$item);
	} // end of member function addItem

	  /**
	   *
	   * @param string current_url    
	   * @return bool
	   * @access public
	   */

	//function to check if any of SubMenu elements are Active
	function isActive( $current_url ) {
		foreach(array_keys($this->elements) as $index) {
			if ($this->elements[$index]->isActive($current_url)) {
				return TRUE;
			}
		}
		return FALSE;
	} // end of member function isActive

} // end of SubMenu

//class to create the permanently closed (folded) SubMenu
class FoldedSubMenu extends SubMenu {

	  /**
	   *
	   * @param string current_url    
	   * @return
	   * @access public
	   */

	function draw($current_url) {
		if(! $this->isVisible($current_url)) {
			return;
		}
		//call MenuItem's (superclass) method draw
		MenuItem::draw($current_url);
	} // end of member function draw

}

//class to create the permanently closed (folded) SubMenu
class HiddenSubMenu extends SubMenu {
	
	function isEmpty( $current_url ) {
		if (! $this->isActive($current_url)) {
			return TRUE;
		} else {
			return FALSE;
		}
	} // end of member function isVisible

	  /**
	   *
	   * @param string current_url    
	   * @return
	   * @access public
	   */

	function draw($current_url) {
		if($this->isActive($current_url)) { 
			SubMenu::draw($current_url);
		} else {
			return;
		}
		//call MenuItem's (superclass) method draw
	} // end of member function draw

}


//function for faster creation of SubMenus
function newSubMenu($my_title,$my_path,$base_url,$my_elements=array()) {
	$sub_menu=new SubMenu($my_title,$my_path);
	$sub_menu->setBaseURL($base_url);
	if (!empty($my_elements)) {
		foreach($my_elements as $key => $value) {
			$sub_menu->addItem($value);
		}
	}
	return $sub_menu;
}

?>
