<?php
	/*** class Menu*/
	class Menu {

		/** Aggregations: */
		var $elements;

		/*** Attributes: ***/
		var $title; //menu Title
		var $base_url; //site URL

		function Menu($my_title, $my_base_url) {
			$this->title=$my_title;
			$this->base_url=$my_base_url;
			$this->elements=array();
		}

		//the function gets parameter current_url and returns nothing
		//anybody can call this method
		/**
		   *
		   * @param string current_url
		   * @return 
		   * @access public
		   */

		// function that draws the menu and all sub elements
		function draw($current_url) {
			echo '<h3 class="leftNav-title"><a href="'.$this->base_url.'">'.$this->title."</a></h3>\n";
			echo "<ul class='leftNav'>";
			foreach(array_keys($this->elements) as $index) {
				if (! $this->elements[$index]->isEmpty($current_url)) {
					if ($this->elements[$index]->isVisible($current_url) and $this->elements[$index]->isActive($current_url)) { 
						echo '<li class="active">';
					} elseif ($this->elements[$index]->isVisible($current_url)) {
						$mc=$this->elements[$index]->getClass();
						if (!empty ($mc)) {
							echo '<li class="'.$mc.'">';
						} else {
							echo '<li>';
						}
					}
					$this->elements[$index]->draw($current_url);
					if($this->elements[$index]->isVisible($current_url)) {
						echo "</li>";
					}
				}
			}
			echo "</ul>";
		} // end of member function draw

		  /**
		   *
		   * @return string
		   * @access public
		   */

		// function to get menuTitle
		function getTitle( ) {
			return $this->title;
		} // end of member function getTitle

		  /**
		   *
		   * @param string new_title    
		   * @return 
		   * @access public
		   */
		 
		//function to set menu Title 
		function setTitle( $new_title ) {
			$this->title=$new_title;
		} // end of member function setTitle

		  /**
		   *
		   * @return string
		   * @access public
		   */

		//function to get site Base URL
		function getBaseURL( ) {
			return $this->base_url;
		} // end of member function getBaseURL

		  /**
		   *
		   * @param string new_base_url    
		   * @return 
		   * @access public
		   */

		//function to set site Base URL
		function setBaseURL( $new_base_url ) {
			$this->base_url=$new_base_url;
		} // end of member function setBaseURL

		  /**
		   *
		   * @param MenuItem item    
		   * @return 
		   * @access public
		   */

		//function to add an Item to menu
		function addItem($item) {
			$item->setBaseURL($this->getBaseURL());
			array_push($this->elements,$item);
		} // end of member function addItem

		  /**
		   *
		   * @return 
		   * @abstract
		   * @access public
		   */

		//function to delete the Item from menu
		function deleteItem( ) {
		    
		} // end of member function deleteItem

		function isActive( $current_url ) {
			foreach(array_keys($this->elements) as $index) {
				if ($this->elements[$index]->isActive($current_url)) {
					return TRUE;
				}
			}
			return FALSE;
		} // end of member function isActive

	} // end of Menu
	
	class HidingMenu extends Menu {
		function draw($current_url) {
			if ($this->isActive($current_url)) {
				echo '<h3 class="leftNav-title"><a href="'.$this->base_url.'">'.$this->title."</a></h3>\n";
				echo "<ul class='leftNav'>";
				foreach(array_keys($this->elements) as $index) {
					if($this->elements[$index]->isVisible($current_url) and $this->elements[$index]->isActive($current_url)) { 
						echo '<li class="active">';
					} elseif ($this->elements[$index]->isVisible($current_url)) {
						$mc=$this->elements[$index]->getClass();
						if (!empty ($mc)) {
							echo '<li class="'.$mc.'">';
						} else {
							echo '<li>';
						}
					}
					$this->elements[$index]->draw($current_url);
					if($this->elements[$index]->isVisible($current_url)) {
						echo "</li>";
					}
				}
				echo "</ul>";
			}
		} // end of member function draw
		
	}


	class CollapsingMenu extends Menu {
		function draw($current_url) {
			echo '<h3 class="leftNav-title"><a href="'.$this->base_url.'">'.$this->title."</a></h3>\n";
			if ($this->isActive($current_url)) {
				echo "<ul class='leftNav'>";
				foreach(array_keys($this->elements) as $index) {
					if($this->elements[$index]->isVisible($current_url) and $this->elements[$index]->isActive($current_url)) { 
						echo '<li class="active">';
					} elseif ($this->elements[$index]->isVisible($current_url)) {
						$mc=$this->elements[$index]->getClass();
						if (!empty ($mc)) {
							echo '<li class="'.$mc.'">';
						} else {
							echo '<li>';
						}
					}
					$this->elements[$index]->draw($current_url);
					if($this->elements[$index]->isVisible($current_url)) {
						echo "</li>";
					}
				}
				echo "</ul>";
			}
		} // end of member function draw
		
	}

	
?>