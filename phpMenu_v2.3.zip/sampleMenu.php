<?php
	//Include the phpMenu library
	include ('classes/phpmenu.php');
	$link="http://".$_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"];
	
	//Sample Website Collapsing Menu
	$menu=new CollapsingMenu ('Sample Website','http://sitetest.athabascau.ca/~helenm/sample-website/');
		$menu->addItem (new HiddenItem('Index',''));
		$menu->addItem (new HiddenItem('Index','index.php'));
		//Contact Us MenuItem
		$menu->addItem (new MenuItem('Contact','contact.php'));
			//Advertising Section with MenuItems and a Subsection
			$sub_menu=new SubMenu ('Advertising','advertising/');
			$sub_menu->setBaseURL($menu->getBaseURL());
			$sub_menu->addItem (new HiddenItem('Index','advertising/index.php'));
			$sub_menu->addItem (new HiddenItem('Index','advertising/'));
				$sub2_menu=new SubMenu ('Advertising Articles','advertising/articles.php');
				$sub2_menu->setBaseURL($menu->getBaseURL());
				$sub2_menu->addItem (new HiddenItem('Index','advertising/articles.php'));
					$sub3_menu=new SubMenu ('2010','advertising/articles.php?year=2010');
					$sub3_menu->setBaseURL($menu->getBaseURL());
					$sub3_menu->addItem (new HiddenItem('Index','advertising/articles.php?year=2010'));
					$sub3_menu->addItem (new GETQueryHiddenItem('Any Article for 2010','advertising/articles.php','year','2010'));
				$sub2_menu->addItem($sub3_menu);
					$sub3_menu=new SubMenu ('2009','advertising/articles.php?year=2009');
					$sub3_menu->setBaseURL($menu->getBaseURL());
					$sub3_menu->addItem (new HiddenItem('Index','advertising/articles.php?year=2009'));
					$sub3_menu->addItem (new GETQueryHiddenItem('Any Article for 2009','advertising/articles.php','year','2009'));
				$sub2_menu->addItem($sub3_menu);
					$sub3_menu=new SubMenu ('2008','advertising/articles.php?year=2008');
					$sub3_menu->setBaseURL($menu->getBaseURL());
					$sub3_menu->addItem (new HiddenItem('Index','advertising/articles.php?year=2008'));
					$sub3_menu->addItem (new GETQueryHiddenItem('Any Article for 2008','advertising/articles.php','year','2008'));
				$sub2_menu->addItem($sub3_menu);
			$sub_menu->addItem($sub2_menu);
			$sub_menu->addItem (new MenuItem('Organizations','advertising/organizations.php'));
			$sub_menu->addItem (new MenuItem('Policy','advertising/policy.php'));
			$sub_menu->addItem (new MenuItem('Resources','advertising/resources.php'));
		$menu->addItem($sub_menu);
			//Culture Section with MenuItems and a Subsection
			$sub_menu=new SubMenu ('Culture','culture/');
			$sub_menu->setBaseURL($menu->getBaseURL());
			$sub_menu->addItem (new HiddenItem('Index','culture/index.php'));
			$sub_menu->addItem (new HiddenItem('Index','culture/'));
				$sub2_menu=new SubMenu ('Our Heritage','culture/our-heritage.php');
				$sub2_menu->setBaseURL($menu->getBaseURL());
				$sub2_menu->addItem (new HiddenItem('Index','culture/our-heritage.php'));
				$sub2_menu->addItem (new MenuItem('2010','culture/our-heritage-2010.php'));
				$sub2_menu->addItem (new MenuItem('2009','culture/our-heritage-2009.php'));
				$sub2_menu->addItem (new MenuItem('2008','culture/our-heritage-2008.php'));
			$sub_menu->addItem($sub2_menu);
			$sub_menu->addItem (new MenuItem('Cultural Studies','culture/cultural-studies.php'));
			$sub_menu->addItem (new MenuItem('Popular Culture','culture/pop.php'));
		$menu->addItem($sub_menu);
		//Media Industry MenuItem
		$menu->addItem (new InactiveItem('Media Industry','industry/'));
			//Alternative Media Navigation
			$sub_menu=new SubMenu ('Alternative Media','alternative.php');
			$sub_menu->setBaseURL($menu->getBaseURL());
			$sub_menu->addItem (new HiddenItem('Index','alternative.php'));
				$sub_sub_menu=new SubMenu ('NewLine Media','newline/');
				$sub_sub_menu->setBaseURL($menu->getBaseURL());
				$sub_sub_menu->addItem (new HiddenItem('Index','newline/index.php'));
				$sub_sub_menu->addItem (new HiddenItem('Index','newline/'));
				$sub_sub_menu->addItem (new MenuItem('Articles/Papers','newline/articles.php'));
				$sub_sub_menu->addItem (new MenuItem('Journals','newline/journals.php'));
				$sub_sub_menu->addItem (new PassiveItem('-----------------','#','lefty'));
				$sub_sub_menu->addItem (new MenuItem('Museums','newline/museums.php'));
				$sub_sub_menu->addItem (new PassiveItem('-----------------','#','lefty'));
				$sub_sub_menu->addItem (new MenuItem('Resources','newline/resources.php'));
			$sub_menu->addItem($sub_sub_menu);			
			$sub_menu->addItem (new MenuItem('Independent Media','independent.php'));
			$sub_menu->addItem (new ExternalItem('Online Resources','http://some-external-site/'));
		$menu->addItem($sub_menu);
		//FAQs Navigation
		//$menu->addItem (new MenuItem('FAQs','faqs.php','important'));
		$menu->addItem (new MenuItem('FAQs','faqs.php'));
	//Draw the Navigation
	$menu->draw($link);
	//End Sample Website Collapsing Menu

	//Media Industry Hiding Menu
	$menu=new HidingMenu ('Media Industry','http://sitetest.athabascau.ca/~helenm/sample-website/industry/');
		$menu->addItem (new HiddenItem('Index',''));
		$menu->addItem (new HiddenItem('Index','index.php'));
		$menu->addItem (new MenuItem('Associations and Organizations','organizations.php'));
			//Media News Section with MenuItems
			$sub_menu=new SubMenu ('Media News','media-news/');
			$sub_menu->setBaseURL($menu->getBaseURL());
			$sub_menu->addItem (new HiddenItem('Index','media-news/index.php'));
			$sub_menu->addItem (new HiddenItem('Index','media-news/'));
			$sub_menu->addItem (new MenuItem('2008','media-news/2008.php','green'));
			$sub_menu->addItem (new MenuItem('2007','media-news/2007.php'));
			$sub_menu->addItem (new MenuItem('2006','media-news/2006.php'));
	 	$menu->addItem($sub_menu);
	//Draw the Navigation
	$menu->draw($link);
	//End Media Industry Hiding Menu

	//Information About Menu
	$menu=new Menu ('Information About','http://sitetest.athabascau.ca/~helenm/sample-website/about/');
		$menu->addItem (new HiddenItem('Index',''));
		$menu->addItem (new HiddenItem('Index','index.php'));
		$menu->addItem (new ExternalItem('Courses','http://www.courses.org/'));
		$menu->addItem (new ExternalItem('Programs','http://www.programs.org/'));
	//Draw the Navigation
	$menu->draw($link);
	//End Information About Menu
?>